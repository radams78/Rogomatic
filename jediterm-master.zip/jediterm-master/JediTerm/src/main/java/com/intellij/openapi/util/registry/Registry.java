package com.intellij.openapi.util.registry;

/**
 * Created by traff on 22/08/16.
 */
public class Registry {
    public static boolean is(String s) {
        return true;
    }
}
