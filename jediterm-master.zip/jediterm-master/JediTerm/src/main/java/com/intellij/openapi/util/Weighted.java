package com.intellij.openapi.util;

public interface Weighted {
  double getWeight();
}
