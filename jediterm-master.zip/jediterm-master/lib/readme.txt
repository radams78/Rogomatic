* pty4j - Java PTY implementation - https://github.com/traff/pty4j
* cyglaunch.exe is a part of pty4j library licensed under Eclipse Public License and is linked with Cygwin™ according to Cygwin™ Open Source
  Licensing Exception (see https://cygwin.com/licensing.html)
* purejavacomm - we use forked version that fixes JNA and YourKit Profiler incompatibility - https://github.com/traff/purejavacomm
* libwinpty.dll and winpty-agent.exe - Windows PTY native implementation used by pty4j, we use forked version from https://github.com/traff/winpty