/**
 * 
 */
package com.jediterm.terminal;

public enum RequestOrigin{
	User,
	Remote
}