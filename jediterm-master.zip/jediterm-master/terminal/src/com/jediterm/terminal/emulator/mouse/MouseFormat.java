package com.jediterm.terminal.emulator.mouse;

/**
 * @author traff
 */
public enum MouseFormat {
  MOUSE_FORMAT_XTERM_EXT,
  MOUSE_FORMAT_URXVT,
  MOUSE_FORMAT_SGR,
  MOUSE_FORMAT_XTERM
}
