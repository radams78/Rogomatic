package com.jediterm.terminal.model;

/**
 * @author traff
 */
public interface TerminalModelListener {
  void modelChanged();
}
