package com.jediterm.terminal.ui;

public interface TerminalWidgetListener {
  void allSessionsClosed(TerminalWidget widget);
}
