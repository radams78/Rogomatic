package com.jediterm.terminal.ui.settings;

public interface SettingsProvider extends SystemSettingsProvider, UserSettingsProvider {
}
