package com.jediterm.terminal.ui;

/**
 * @author traff
 */
public interface TerminalCoordinates {
  int getX();
  void setX(int x);
  int getY();
  void setY(int y);
}
